import { getServerSession } from "next-auth"
import { authOptions } from "./options"
import { prisma } from "@/lib/prisma"

export async function getCurrentUser() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  })
  return user
}

export async function requireAuth() {
  const user = await getCurrentUser()
  if (!user) throw new Error("Unauthorized")
  return user
}

export async function requireAdmin() {
  const user = await getCurrentUser()
  if (!user) throw new Error("Unauthorized")
  if (user.role !== "admin" && user.role !== "super_admin") {
    throw new Error("Forbidden: Admin access required")
  }
  return user
}
