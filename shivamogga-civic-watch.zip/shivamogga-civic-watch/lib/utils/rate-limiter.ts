type RateLimitStore = {
  [key: string]: { count: number; resetTime: number }
}

const store: RateLimitStore = {}

export function checkRateLimit(identifier: string, limit: number, windowMs: number): { allowed: boolean; retryAfter: number } {
  const now = Date.now()
  const record = store[identifier]

  if (!record || now > record.resetTime) {
    store[identifier] = { count: 1, resetTime: now + windowMs }
    return { allowed: true, retryAfter: 0 }
  }

  if (record.count >= limit) {
    const retryAfter = Math.ceil((record.resetTime - now) / 1000)
    return { allowed: false, retryAfter }
  }

  record.count++
  return { allowed: true, retryAfter: 0 }
}

export function checkReportRateLimit(identifier: string): { allowed: boolean; retryAfter: number } {
  return checkRateLimit(`report:${identifier}`, 3, 60 * 60 * 1000) // 3 per hour
}
