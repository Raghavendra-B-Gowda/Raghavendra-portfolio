import { z } from 'zod'

export const reportSchema = z.object({
  title: z.string().min(10, 'Title must be at least 10 characters').max(200, 'Title must be under 200 characters'),
  description: z.string().min(30, 'Description must be at least 30 characters').max(2000, 'Description must be under 2000 characters'),
  category_id: z.string().uuid('Please select a category'),
  taluka_id: z.string().uuid('Please select a taluka'),
  location_address: z.string().max(500).optional().nullable(),
  latitude: z.number().min(-90).max(90).optional().nullable(),
  longitude: z.number().min(-180).max(180).optional().nullable(),
  images: z.array(z.object({
    url: z.string().url(),
    path: z.string(),
    name: z.string()
  })).max(3, 'Maximum 3 images allowed').default([]),
  is_anonymous: z.boolean().default(true),
  author_name: z.string().min(2).max(100).optional().nullable(),
  author_phone: z.string().regex(/^\+91[0-9]{10}$/, 'Invalid Indian phone number').optional().nullable(),
}).refine((data) => {
  if (!data.is_anonymous) {
    return !!data.author_name && !!data.author_phone
  }
  return true
}, {
  message: 'Name and phone are required when not posting anonymously',
  path: ['author_name'],
})

export const reviewSchema = z.object({
  action: z.enum(['approve', 'reject', 'resolve']),
  admin_note: z.string().max(1000).optional().nullable(),
})

export const settingsSchema = z.object({
  site_name: z.string().min(1).max(100).optional(),
  site_tagline: z.string().max(200).optional().nullable(),
  contact_email: z.string().email().optional().nullable(),
  moderation_guidelines: z.string().optional().nullable(),
  primary_color: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
  maintenance_mode: z.boolean().optional(),
})

export const banUserSchema = z.object({
  is_banned: z.boolean(),
  reason: z.string().max(500).optional().nullable(),
})

export const uploadPresignSchema = z.object({
  filename: z.string().min(1),
  filetype: z.enum(['image/jpeg', 'image/png', 'image/webp']),
  filesize: z.number().max(5 * 1024 * 1024, 'File must be under 5MB'),
})
