import { cloudinary } from "./cloudinary"

export async function getCloudinarySignature() {
  const timestamp = Math.round(new Date().getTime() / 1000)
  const signature = cloudinary.utils.api_sign_request(
    { timestamp, folder: "shivamogga-reports" },
    process.env.CLOUDINARY_API_SECRET!
  )

  return {
    signature,
    timestamp,
    apiKey: process.env.CLOUDINARY_API_KEY!,
    cloudName: process.env.CLOUDINARY_CLOUD_NAME!,
  }
}

export function getCloudinaryUrl(publicId: string, options: { width?: number; height?: number; crop?: string } = {}) {
  return cloudinary.url(publicId, {
    secure: true,
    transformation: [
      { width: options.width, height: options.height, crop: options.crop || "limit" },
      { quality: "auto", fetch_format: "auto" },
    ],
  })
}
