import { PrismaClient } from '@prisma/client'

export async function generateReferenceId(prisma: PrismaClient): Promise<string> {
  const year = new Date().getFullYear()
  const count = await prisma.report.count()
  const next = (count + 1).toString().padStart(5, '0')
  return `SCW-${year}-${next}`
}
