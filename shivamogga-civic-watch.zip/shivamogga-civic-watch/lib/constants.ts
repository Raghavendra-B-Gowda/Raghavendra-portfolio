export const APP_NAME = 'Shivamogga District Civic Watch'
export const APP_TAGLINE = 'Your Voice, Our District'

export const REPORT_STATUSES = {
  pending: { label: 'Pending Review', color: 'bg-yellow-100 text-yellow-800' },
  approved: { label: 'Approved', color: 'bg-green-100 text-green-800' },
  rejected: { label: 'Rejected', color: 'bg-red-100 text-red-800' },
  resolved: { label: 'Resolved', color: 'bg-blue-100 text-blue-800' },
} as const

export const MAX_IMAGES = 3
export const MAX_FILE_SIZE = 5 * 1024 * 1024 // 5MB
export const RATE_LIMIT_PER_HOUR = 3

export const DISTRICT_CENTER = {
  lat: 13.929930,
  lng: 75.568101,
}

export const MAP_DEFAULT_ZOOM = 11
