import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/options"
import { prisma } from "@/lib/prisma"
import { reportSchema } from "@/lib/utils/validators"
import { generateReferenceId } from "@/lib/utils/reference-id"
import { checkReportRateLimit } from "@/lib/utils/rate-limiter"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"))
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get("limit") || "12")))
    const category = searchParams.get("category")
    const taluka = searchParams.get("taluka")
    const sort = searchParams.get("sort") || "newest"
    const search = searchParams.get("search")

    const where: any = { status: "approved" }

    if (category) {
      const cat = await prisma.category.findUnique({ where: { slug: category } })
      if (cat) where.category_id = cat.id
    }

    if (taluka) {
      const tal = await prisma.taluka.findUnique({ where: { slug: taluka } })
      if (tal) where.taluka_id = tal.id
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
      ]
    }

    const orderBy: any = sort === "most_viewed" 
      ? { view_count: "desc" } 
      : { created_at: sort === "oldest" ? "asc" : "desc" }

    const [reports, total] = await Promise.all([
      prisma.report.findMany({
        where,
        include: {
          category: { select: { id: true, name_en: true, name_kn: true, slug: true, icon: true, color: true } },
          taluka: { select: { id: true, name_en: true, name_kn: true, slug: true } },
        },
        orderBy,
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.report.count({ where }),
    ])

    const sanitized = reports.map(r => ({
      ...r,
      author_name: r.is_anonymous ? null : r.author_name,
      author_phone: r.is_anonymous ? null : r.author_phone,
      user_id: undefined,
      reviewed_by: undefined,
      admin_note: undefined,
    }))

    return NextResponse.json({
      success: true,
      data: { reports: sanitized },
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    })
  } catch (error) {
    console.error("Reports GET error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to fetch reports" } },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "Please sign in to submit a report" } },
        { status: 401 }
      )
    }

    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "User not found" } },
        { status: 401 }
      )
    }

    if (user.is_banned) {
      return NextResponse.json(
        { success: false, error: { code: "FORBIDDEN", message: "Your account has been banned" } },
        { status: 403 }
      )
    }

    // Rate limiting
    const { allowed, retryAfter } = checkReportRateLimit(user.id)
    if (!allowed) {
      return NextResponse.json(
        { success: false, error: { code: "RATE_LIMIT_EXCEEDED", message: "Too many submissions. Please try again later.", retry_after: retryAfter } },
        { status: 429 }
      )
    }

    const body = await request.json()
    const result = reportSchema.safeParse(body)

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: { code: "VALIDATION_ERROR", message: "Invalid report data", details: result.error.flatten() } },
        { status: 400 }
      )
    }

    const data = result.data
    const referenceId = await generateReferenceId(prisma)

    const report = await prisma.report.create({
      data: {
        reference_id: referenceId,
        title: data.title,
        description: data.description,
        category_id: data.category_id,
        taluka_id: data.taluka_id,
        location_address: data.location_address,
        latitude: data.latitude ? new (await import("@prisma/client/runtime/library")).Decimal(data.latitude) : null,
        longitude: data.longitude ? new (await import("@prisma/client/runtime/library")).Decimal(data.longitude) : null,
        images: data.images as any,
        is_anonymous: data.is_anonymous,
        author_name: data.is_anonymous ? null : data.author_name,
        author_phone: data.is_anonymous ? null : data.author_phone,
        user_id: user.id,
        status: "pending",
      },
      include: {
        category: { select: { name_en: true, slug: true } },
        taluka: { select: { name_en: true, slug: true } },
      },
    })

    return NextResponse.json({
      success: true,
      data: { report: { id: report.id, reference_id: report.reference_id, title: report.title, status: report.status } },
      message: "Report submitted successfully. It will be reviewed by our team.",
    }, { status: 201 })
  } catch (error) {
    console.error("Reports POST error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to submit report" } },
      { status: 500 }
    )
  }
}
