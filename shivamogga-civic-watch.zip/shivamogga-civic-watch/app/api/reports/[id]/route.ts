import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/options"
import { prisma } from "@/lib/prisma"
import { reportSchema } from "@/lib/utils/validators"

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    const report = await prisma.report.findUnique({
      where: { id: params.id },
      include: {
        category: { select: { id: true, name_en: true, name_kn: true, slug: true, icon: true, color: true } },
        taluka: { select: { id: true, name_en: true, name_kn: true, slug: true } },
      },
    })

    if (!report) {
      return NextResponse.json(
        { success: false, error: { code: "NOT_FOUND", message: "Report not found" } },
        { status: 404 }
      )
    }

    const currentUser = session?.user?.email 
      ? await prisma.user.findUnique({ where: { email: session.user.email } })
      : null

    const isOwner = currentUser && report.user_id === currentUser.id
    const isAdmin = currentUser && (currentUser.role === "admin" || currentUser.role === "super_admin")

    if (report.status !== "approved" && !isOwner && !isAdmin) {
      return NextResponse.json(
        { success: false, error: { code: "NOT_FOUND", message: "Report not found" } },
        { status: 404 }
      )
    }

    // Increment view count asynchronously
    if (report.status === "approved") {
      prisma.report.update({
        where: { id: params.id },
        data: { view_count: { increment: 1 } },
      }).catch(console.error)
    }

    // Get related reports
    const related = await prisma.report.findMany({
      where: {
        status: "approved",
        id: { not: params.id },
        OR: [
          { taluka_id: report.taluka_id },
          { category_id: report.category_id },
        ],
      },
      include: {
        category: { select: { name_en: true, slug: true, color: true } },
        taluka: { select: { name_en: true, slug: true } },
      },
      take: 3,
      orderBy: { created_at: "desc" },
    })

    const sanitized = {
      ...report,
      author_name: report.is_anonymous && !isAdmin ? null : report.author_name,
      author_phone: report.is_anonymous && !isAdmin ? null : report.author_phone,
      user_id: undefined,
      reviewed_by: isAdmin ? report.reviewed_by : undefined,
      admin_note: isAdmin ? report.admin_note : undefined,
    }

    return NextResponse.json({
      success: true,
      data: { report: sanitized, related },
    })
  } catch (error) {
    console.error("Report GET error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to fetch report" } },
      { status: 500 }
    )
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "Please sign in" } },
        { status: 401 }
      )
    }

    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "User not found" } },
        { status: 401 }
      )
    }

    const existing = await prisma.report.findUnique({ where: { id: params.id } })

    if (!existing) {
      return NextResponse.json(
        { success: false, error: { code: "NOT_FOUND", message: "Report not found" } },
        { status: 404 }
      )
    }

    if (existing.user_id !== user.id) {
      return NextResponse.json(
        { success: false, error: { code: "NOT_OWNER", message: "You can only edit your own reports" } },
        { status: 403 }
      )
    }

    if (existing.status !== "pending") {
      return NextResponse.json(
        { success: false, error: { code: "INVALID_STATUS_TRANSITION", message: "Can only edit pending reports" } },
        { status: 400 }
      )
    }

    const body = await request.json()
    const result = reportSchema.partial().safeParse(body)

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: { code: "VALIDATION_ERROR", message: "Invalid data", details: result.error.flatten() } },
        { status: 400 }
      )
    }

    const data = result.data
    const updated = await prisma.report.update({
      where: { id: params.id },
      data: {
        ...(data.title && { title: data.title }),
        ...(data.description && { description: data.description }),
        ...(data.category_id && { category_id: data.category_id }),
        ...(data.taluka_id && { taluka_id: data.taluka_id }),
        ...(data.location_address !== undefined && { location_address: data.location_address }),
        ...(data.latitude !== undefined && { latitude: data.latitude ? new (await import("@prisma/client/runtime/library")).Decimal(data.latitude) : null }),
        ...(data.longitude !== undefined && { longitude: data.longitude ? new (await import("@prisma/client/runtime/library")).Decimal(data.longitude) : null }),
        ...(data.images && { images: data.images as any }),
        ...(data.is_anonymous !== undefined && { 
          is_anonymous: data.is_anonymous,
          author_name: data.is_anonymous ? null : data.author_name,
          author_phone: data.is_anonymous ? null : data.author_phone,
        }),
      },
      include: {
        category: { select: { name_en: true, slug: true } },
        taluka: { select: { name_en: true, slug: true } },
      },
    })

    return NextResponse.json({
      success: true,
      data: { report: updated },
      message: "Report updated successfully",
    })
  } catch (error) {
    console.error("Report PATCH error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to update report" } },
      { status: 500 }
    )
  }
}
