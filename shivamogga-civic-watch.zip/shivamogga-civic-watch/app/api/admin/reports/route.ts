import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/options"
import { prisma } from "@/lib/prisma"

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "Please sign in" } },
        { status: 401 }
      )
    }

    const admin = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!admin || (admin.role !== "admin" && admin.role !== "super_admin")) {
      return NextResponse.json(
        { success: false, error: { code: "FORBIDDEN", message: "Admin access required" } },
        { status: 403 }
      )
    }

    const { searchParams } = new URL(request.url)
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"))
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get("limit") || "20")))
    const status = searchParams.get("status") as any
    const category = searchParams.get("category")
    const taluka = searchParams.get("taluka")
    const search = searchParams.get("search")

    const where: any = {}
    if (status) where.status = status
    if (category) {
      const cat = await prisma.category.findUnique({ where: { slug: category } })
      if (cat) where.category_id = cat.id
    }
    if (taluka) {
      const tal = await prisma.taluka.findUnique({ where: { slug: taluka } })
      if (tal) where.taluka_id = tal.id
    }
    if (search) {
      where.OR = [
        { title: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
        { reference_id: { contains: search, mode: "insensitive" } },
      ]
    }

    const [reports, total] = await Promise.all([
      prisma.report.findMany({
        where,
        include: {
          category: true,
          taluka: true,
          user: { select: { id: true, email: true, name: true } },
          reviewer: { select: { id: true, name: true, email: true } },
        },
        orderBy: { created_at: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.report.count({ where }),
    ])

    return NextResponse.json({
      success: true,
      data: { reports },
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    })
  } catch (error) {
    console.error("Admin reports error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to fetch admin reports" } },
      { status: 500 }
    )
  }
}
