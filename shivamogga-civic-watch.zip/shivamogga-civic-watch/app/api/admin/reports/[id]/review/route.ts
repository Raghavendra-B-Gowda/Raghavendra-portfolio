import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/options"
import { prisma } from "@/lib/prisma"
import { reviewSchema } from "@/lib/utils/validators"

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "Please sign in" } },
        { status: 401 }
      )
    }

    const admin = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!admin || (admin.role !== "admin" && admin.role !== "super_admin")) {
      return NextResponse.json(
        { success: false, error: { code: "FORBIDDEN", message: "Admin access required" } },
        { status: 403 }
      )
    }

    const body = await request.json()
    const result = reviewSchema.safeParse(body)

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: { code: "VALIDATION_ERROR", message: "Invalid review data", details: result.error.flatten() } },
        { status: 400 }
      )
    }

    const { action, admin_note } = result.data

    const existing = await prisma.report.findUnique({ where: { id: params.id } })
    if (!existing) {
      return NextResponse.json(
        { success: false, error: { code: "NOT_FOUND", message: "Report not found" } },
        { status: 404 }
      )
    }

    if (existing.status === action) {
      return NextResponse.json(
        { success: false, error: { code: "ALREADY_REVIEWED", message: `Report is already ${action}` } },
        { status: 400 }
      )
    }

    const updated = await prisma.report.update({
      where: { id: params.id },
      data: {
        status: action,
        admin_note: admin_note || null,
        reviewed_by: admin.id,
        reviewed_at: new Date(),
      },
    })

    // Log activity
    await prisma.activityLog.create({
      data: {
        report_id: params.id,
        action,
        performed_by: admin.id,
        note: admin_note,
        metadata: { previous_status: existing.status },
      },
    })

    return NextResponse.json({
      success: true,
      data: { report: updated },
      message: `Report ${action}d successfully`,
    })
  } catch (error) {
    console.error("Admin review error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to review report" } },
      { status: 500 }
    )
  }
}
