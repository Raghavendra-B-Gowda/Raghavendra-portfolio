import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/options"
import { prisma } from "@/lib/prisma"
import { settingsSchema } from "@/lib/utils/validators"

export async function GET() {
  try {
    const settings = await prisma.adminSetting.findUnique({ where: { id: 1 } })
    if (!settings) {
      return NextResponse.json(
        { success: false, error: { code: "NOT_FOUND", message: "Settings not found" } },
        { status: 404 }
      )
    }
    return NextResponse.json({ success: true, data: { settings } })
  } catch (error) {
    console.error("Settings GET error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to fetch settings" } },
      { status: 500 }
    )
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "Please sign in" } },
        { status: 401 }
      )
    }

    const admin = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!admin || (admin.role !== "admin" && admin.role !== "super_admin")) {
      return NextResponse.json(
        { success: false, error: { code: "FORBIDDEN", message: "Admin access required" } },
        { status: 403 }
      )
    }

    const body = await request.json()
    const result = settingsSchema.safeParse(body)

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: { code: "VALIDATION_ERROR", message: "Invalid settings data", details: result.error.flatten() } },
        { status: 400 }
      )
    }

    const data = result.data
    const updated = await prisma.adminSetting.update({
      where: { id: 1 },
      data: {
        ...(data.site_name && { site_name: data.site_name }),
        ...(data.site_tagline !== undefined && { site_tagline: data.site_tagline }),
        ...(data.contact_email !== undefined && { contact_email: data.contact_email }),
        ...(data.moderation_guidelines !== undefined && { moderation_guidelines: data.moderation_guidelines }),
        ...(data.primary_color && { primary_color: data.primary_color }),
        ...(data.maintenance_mode !== undefined && { maintenance_mode: data.maintenance_mode }),
      },
    })

    await prisma.activityLog.create({
      data: {
        report_id: "system",
        action: "update_settings",
        performed_by: admin.id,
        note: "Updated site settings",
        metadata: data,
      },
    })

    return NextResponse.json({
      success: true,
      data: { settings: updated },
      message: "Settings updated successfully",
    })
  } catch (error) {
    console.error("Settings PUT error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to update settings" } },
      { status: 500 }
    )
  }
}
