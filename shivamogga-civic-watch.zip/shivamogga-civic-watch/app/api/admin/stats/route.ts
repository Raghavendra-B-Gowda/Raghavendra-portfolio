import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/options"
import { prisma } from "@/lib/prisma"

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "Please sign in" } },
        { status: 401 }
      )
    }

    const admin = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!admin || (admin.role !== "admin" && admin.role !== "super_admin")) {
      return NextResponse.json(
        { success: false, error: { code: "FORBIDDEN", message: "Admin access required" } },
        { status: 403 }
      )
    }

    const now = new Date()
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)

    const [
      total,
      pending,
      approved,
      rejected,
      resolved,
      todayCount,
      categoryBreakdown,
      talukaBreakdown,
      last30Days,
      reviewStats,
    ] = await Promise.all([
      prisma.report.count(),
      prisma.report.count({ where: { status: "pending" } }),
      prisma.report.count({ where: { status: "approved" } }),
      prisma.report.count({ where: { status: "rejected" } }),
      prisma.report.count({ where: { status: "resolved" } }),
      prisma.report.count({ where: { created_at: { gte: todayStart } } }),
      prisma.report.groupBy({
        by: ["category_id"],
        _count: { category_id: true },
      }),
      prisma.report.groupBy({
        by: ["taluka_id"],
        _count: { taluka_id: true },
      }),
      prisma.report.findMany({
        where: { created_at: { gte: thirtyDaysAgo } },
        select: { created_at: true, status: true },
      }),
      prisma.report.findMany({
        where: { reviewed_at: { not: null } },
        select: { created_at: true, reviewed_at: true, status: true },
      }),
    ])

    const categories = await prisma.category.findMany()
    const talukas = await prisma.taluka.findMany()
    const categoryMap = new Map(categories.map(c => [c.id, c]))
    const talukaMap = new Map(talukas.map(t => [t.id, t]))

    const trendsMap = new Map()
    for (let i = 0; i < 30; i++) {
      const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000)
      const key = d.toISOString().split("T")[0]
      trendsMap.set(key, { date: key, count: 0, approved: 0, pending: 0 })
    }
    last30Days.forEach(r => {
      const key = r.created_at.toISOString().split("T")[0]
      if (trendsMap.has(key)) {
        const t = trendsMap.get(key)
        t.count++
        if (r.status === "approved") t.approved++
        if (r.status === "pending") t.pending++
      }
    })
    const trends = Array.from(trendsMap.values()).reverse()

    let totalReviewHours = 0
    let reviewedCount = 0
    reviewStats.forEach(r => {
      if (r.reviewed_at) {
        const hours = (r.reviewed_at.getTime() - r.created_at.getTime()) / (1000 * 60 * 60)
        totalReviewHours += hours
        reviewedCount++
      }
    })
    const avgReviewTime = reviewedCount > 0 ? Math.round(totalReviewHours / reviewedCount * 10) / 10 : 0

    const approvedCount = reviewStats.filter(r => r.status === "approved").length
    const approvalRate = reviewedCount > 0 ? Math.round((approvedCount / reviewedCount) * 100) : 0

    return NextResponse.json({
      success: true,
      data: {
        overview: { total, pending, approved, rejected, resolved, today: todayCount },
        trends,
        by_category: categoryBreakdown.map(cb => ({
          name: categoryMap.get(cb.category_id)?.name_en || "Unknown",
          count: cb._count.category_id,
          percentage: total > 0 ? Math.round((cb._count.category_id / total) * 100) : 0,
        })),
        by_taluka: talukaBreakdown.map(tb => ({
          name: talukaMap.get(tb.taluka_id)?.name_en || "Unknown",
          count: tb._count.taluka_id,
          percentage: total > 0 ? Math.round((tb._count.taluka_id / total) * 100) : 0,
        })),
        by_status_history: { avg_review_time_hours: avgReviewTime, approval_rate: approvalRate },
      },
    })
  } catch (error) {
    console.error("Admin stats error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to fetch stats" } },
      { status: 500 }
    )
  }
}
