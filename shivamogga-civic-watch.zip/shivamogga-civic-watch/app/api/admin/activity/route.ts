import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/options"
import { prisma } from "@/lib/prisma"

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "Please sign in" } },
        { status: 401 }
      )
    }

    const admin = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!admin || (admin.role !== "admin" && admin.role !== "super_admin")) {
      return NextResponse.json(
        { success: false, error: { code: "FORBIDDEN", message: "Admin access required" } },
        { status: 403 }
      )
    }

    const { searchParams } = new URL(request.url)
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"))
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get("limit") || "50")))
    const reportId = searchParams.get("report_id")
    const action = searchParams.get("action")

    const where: any = {}
    if (reportId && reportId !== "system") where.report_id = reportId
    if (action) where.action = action

    const [activities, total] = await Promise.all([
      prisma.activityLog.findMany({
        where,
        include: {
          report: { select: { title: true } },
          user: { select: { name: true, email: true } },
        },
        orderBy: { created_at: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.activityLog.count({ where }),
    ])

    return NextResponse.json({
      success: true,
      data: {
        activities: activities.map(a => ({
          id: a.id,
          report_id: a.report_id,
          report_title: a.report?.title || "System",
          action: a.action,
          performed_by: { name: a.user.name, email: a.user.email },
          note: a.note,
          created_at: a.created_at,
        })),
      },
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    })
  } catch (error) {
    console.error("Admin activity error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to fetch activity log" } },
      { status: 500 }
    )
  }
}
