import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/options"
import { prisma } from "@/lib/prisma"
import { banUserSchema } from "@/lib/utils/validators"

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "Please sign in" } },
        { status: 401 }
      )
    }

    const admin = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!admin || (admin.role !== "admin" && admin.role !== "super_admin")) {
      return NextResponse.json(
        { success: false, error: { code: "FORBIDDEN", message: "Admin access required" } },
        { status: 403 }
      )
    }

    const { searchParams } = new URL(request.url)
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"))
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get("limit") || "20")))
    const search = searchParams.get("search")
    const role = searchParams.get("role")
    const isBanned = searchParams.get("is_banned")

    const where: any = {}
    if (search) {
      where.OR = [
        { email: { contains: search, mode: "insensitive" } },
        { name: { contains: search, mode: "insensitive" } },
      ]
    }
    if (role) where.role = role
    if (isBanned !== null) where.is_banned = isBanned === "true"

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        select: {
          id: true,
          email: true,
          name: true,
          avatar_url: true,
          role: true,
          is_banned: true,
          created_at: true,
          _count: { select: { reports: true } },
        },
        orderBy: { created_at: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.user.count({ where }),
    ])

    return NextResponse.json({
      success: true,
      data: {
        users: users.map(u => ({
          ...u,
          report_count: u._count.reports,
          _count: undefined,
        })),
      },
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    })
  } catch (error) {
    console.error("Admin users error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to fetch users" } },
      { status: 500 }
    )
  }
}

export async function PATCH(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "Please sign in" } },
        { status: 401 }
      )
    }

    const admin = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!admin || (admin.role !== "admin" && admin.role !== "super_admin")) {
      return NextResponse.json(
        { success: false, error: { code: "FORBIDDEN", message: "Admin access required" } },
        { status: 403 }
      )
    }

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("id")
    if (!userId) {
      return NextResponse.json(
        { success: false, error: { code: "VALIDATION_ERROR", message: "User ID required" } },
        { status: 400 }
      )
    }

    const body = await request.json()
    const result = banUserSchema.safeParse(body)

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: { code: "VALIDATION_ERROR", message: "Invalid data", details: result.error.flatten() } },
        { status: 400 }
      )
    }

    const { is_banned, reason } = result.data

    const updated = await prisma.user.update({
      where: { id: userId },
      data: { is_banned, banned_reason: reason },
    })

    await prisma.activityLog.create({
      data: {
        report_id: "system",
        action: is_banned ? "ban" : "unban",
        performed_by: admin.id,
        note: reason,
        metadata: { target_user_id: userId, target_user_email: updated.email },
      },
    })

    return NextResponse.json({
      success: true,
      data: { user: updated },
      message: `User ${is_banned ? "banned" : "unbanned"} successfully`,
    })
  } catch (error) {
    console.error("Admin ban error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to update user" } },
      { status: 500 }
    )
  }
}
