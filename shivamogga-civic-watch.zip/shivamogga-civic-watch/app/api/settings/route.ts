import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const settings = await prisma.adminSetting.findUnique({ where: { id: 1 } })
    if (!settings) {
      return NextResponse.json(
        { success: false, error: { code: 'NOT_FOUND', message: 'Settings not found' } },
        { status: 404 }
      )
    }
    return NextResponse.json({ success: true, data: { settings } })
  } catch (error) {
    console.error('Settings error:', error)
    return NextResponse.json(
      { success: false, error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch settings' } },
      { status: 500 }
    )
  }
}
