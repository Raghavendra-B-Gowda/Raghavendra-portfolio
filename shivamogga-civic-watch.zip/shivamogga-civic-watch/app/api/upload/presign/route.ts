import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/options"
import { getCloudinarySignature } from "@/lib/utils/cloudinary-upload"
import { uploadPresignSchema } from "@/lib/utils/validators"

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json(
        { success: false, error: { code: "UNAUTHORIZED", message: "Please sign in to upload images" } },
        { status: 401 }
      )
    }

    const body = await request.json()
    const result = uploadPresignSchema.safeParse(body)

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: { code: "VALIDATION_ERROR", message: "Invalid upload request", details: result.error.flatten() } },
        { status: 400 }
      )
    }

    const { cloudName, apiKey, signature, timestamp } = await getCloudinarySignature()

    return NextResponse.json({
      success: true,
      data: {
        signature,
        timestamp,
        apiKey,
        cloudName,
        folder: "shivamogga-reports",
      },
    })
  } catch (error) {
    console.error("Upload presign error:", error)
    return NextResponse.json(
      { success: false, error: { code: "INTERNAL_ERROR", message: "Failed to generate upload signature" } },
      { status: 500 }
    )
  }
}
