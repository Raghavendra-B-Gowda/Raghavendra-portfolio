import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const talukas = await prisma.taluka.findMany({
      where: { is_active: true },
      orderBy: { sort_order: 'asc' },
    })
    return NextResponse.json({ success: true, data: { talukas } })
  } catch (error) {
    console.error('Talukas error:', error)
    return NextResponse.json(
      { success: false, error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch talukas' } },
      { status: 500 }
    )
  }
}
