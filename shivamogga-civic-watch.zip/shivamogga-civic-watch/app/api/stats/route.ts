import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const [
      total,
      approved,
      pending,
      resolved,
      rejected,
      categoryBreakdown,
      talukaBreakdown,
    ] = await Promise.all([
      prisma.report.count(),
      prisma.report.count({ where: { status: 'approved' } }),
      prisma.report.count({ where: { status: 'pending' } }),
      prisma.report.count({ where: { status: 'resolved' } }),
      prisma.report.count({ where: { status: 'rejected' } }),
      prisma.report.groupBy({
        by: ['category_id'],
        where: { status: 'approved' },
        _count: { category_id: true },
      }),
      prisma.report.groupBy({
        by: ['taluka_id'],
        where: { status: 'approved' },
        _count: { taluka_id: true },
      }),
    ])

    const categories = await prisma.category.findMany({ where: { is_active: true } })
    const talukas = await prisma.taluka.findMany({ where: { is_active: true } })

    const categoryMap = new Map(categories.map(c => [c.id, c]))
    const talukaMap = new Map(talukas.map(t => [t.id, t]))

    return NextResponse.json({
      success: true,
      data: {
        total_reports: total,
        approved_reports: approved,
        pending_reports: pending,
        resolved_reports: resolved,
        rejected_reports: rejected,
        category_breakdown: categoryBreakdown.map(cb => ({
          category: categoryMap.get(cb.category_id)?.name_en || 'Unknown',
          count: cb._count.category_id,
          color: categoryMap.get(cb.category_id)?.color || '#6b7280',
        })),
        taluka_breakdown: talukaBreakdown.map(tb => ({
          taluka: talukaMap.get(tb.taluka_id)?.name_en || 'Unknown',
          count: tb._count.taluka_id,
        })),
      },
    })
  } catch (error) {
    console.error('Stats error:', error)
    return NextResponse.json(
      { success: false, error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch stats' } },
      { status: 500 }
    )
  }
}
