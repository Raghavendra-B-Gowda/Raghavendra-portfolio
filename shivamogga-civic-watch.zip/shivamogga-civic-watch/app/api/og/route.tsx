import { ImageResponse } from '@vercel/og'
import { NextRequest } from 'next/server'

export const runtime = 'edge'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const title = searchParams.get('title') || 'Shivamogga District Civic Watch'
    const category = searchParams.get('category') || 'Civic Report'
    const taluka = searchParams.get('taluka') || 'Shivamogga'
    const imageUrl = searchParams.get('image')

    return new ImageResponse(
      (
        <div
          style={{
            height: '100%',
            width: '100%',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'flex-start',
            justifyContent: 'flex-end',
            backgroundColor: '#0f766e',
            backgroundImage: 'linear-gradient(135deg, #0f766e 0%, #134e4a 100%)',
            padding: '40px',
            position: 'relative',
          }}
        >
          {/* Background pattern */}
          <div
            style={{
              position: 'absolute',
              top: 0,
              right: 0,
              width: '300px',
              height: '300px',
              background: 'radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%)',
            }}
          />

          {/* Logo area */}
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
            <div
              style={{
                width: '48px',
                height: '48px',
                borderRadius: '12px',
                backgroundColor: 'white',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: '16px',
              }}
            >
              <span style={{ fontSize: '28px' }}>📢</span>
            </div>
            <span style={{ fontSize: '20px', color: 'rgba(255,255,255,0.8)', fontWeight: 600 }}>
              Shivamogga Civic Watch
            </span>
          </div>

          {/* Title */}
          <h1
            style={{
              fontSize: '48px',
              fontWeight: 800,
              color: 'white',
              lineHeight: 1.2,
              marginBottom: '16px',
              maxWidth: '800px',
            }}
          >
            {title.length > 80 ? title.slice(0, 80) + '...' : title}
          </h1>

          {/* Meta info */}
          <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
            <span
              style={{
                backgroundColor: 'rgba(255,255,255,0.2)',
                color: 'white',
                padding: '8px 16px',
                borderRadius: '8px',
                fontSize: '18px',
                fontWeight: 600,
              }}
            >
              {category}
            </span>
            <span style={{ fontSize: '18px', color: 'rgba(255,255,255,0.7)' }}>
              📍 {taluka}
            </span>
          </div>

          {/* Footer */}
          <div
            style={{
              position: 'absolute',
              bottom: '40px',
              right: '40px',
              fontSize: '16px',
              color: 'rgba(255,255,255,0.6)',
            }}
          >
            shivamoggacivicwatch.org
          </div>
        </div>
      ),
      {
        width: 1200,
        height: 630,
      }
    )
  } catch (error) {
    console.error('OG image error:', error)
    return new Response('Failed to generate image', { status: 500 })
  }
}
