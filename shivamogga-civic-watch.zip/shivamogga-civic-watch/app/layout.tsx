import type { Metadata } from 'next'
import { Inter, Noto_Sans_Kannada } from 'next/font/google'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth/options'
import { SessionProvider } from '@/components/providers/SessionProvider'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-sans' })
const notoSansKannada = Noto_Sans_Kannada({ 
  subsets: ['kannada'], 
  weight: ['400', '500', '600', '700'],
  variable: '--font-kannada' 
})

export const metadata: Metadata = {
  title: 'Shivamogga District Civic Watch',
  description: 'Report civic issues in Shivamogga District anonymously. Roads, water, waste, corruption — your voice matters.',
  keywords: ['Shivamogga', 'civic issues', 'corruption', 'transparency', 'Karnataka', 'Malnad'],
  authors: [{ name: 'Shivamogga Civic Watch' }],
  openGraph: {
    title: 'Shivamogga District Civic Watch',
    description: 'Your Voice, Our District — Report Civic Issues Anonymously',
    type: 'website',
    locale: 'en_IN',
  },
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await getServerSession(authOptions)

  return (
    <html lang="en" className={`${inter.variable} ${notoSansKannada.variable}`}>
      <body className="font-sans antialiased bg-background text-foreground">
        <SessionProvider session={session}>
          {children}
        </SessionProvider>
      </body>
    </html>
  )
}
