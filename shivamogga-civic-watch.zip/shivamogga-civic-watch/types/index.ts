import { ReportStatus, UserRole, ActivityAction } from '@prisma/client'

export interface Category {
  id: string
  name_en: string
  name_kn: string
  slug: string
  icon: string | null
  color: string
  sort_order: number
}

export interface Taluka {
  id: string
  name_en: string
  name_kn: string
  slug: string
  latitude: number | null
  longitude: number | null
}

export interface ReportImage {
  url: string
  path: string
  name: string
}

export interface Report {
  id: string
  reference_id: string
  title: string
  description: string
  category: Category
  taluka: Taluka
  location_address: string | null
  latitude: number | null
  longitude: number | null
  images: ReportImage[]
  is_anonymous: boolean
  author_name: string | null
  author_phone: string | null
  status: ReportStatus
  view_count: number
  created_at: string
  updated_at: string
}

export interface ReportWithAdmin extends Report {
  user: { email: string; name: string | null } | null
  admin_note: string | null
  reviewed_by: string | null
  reviewed_at: string | null
}

export interface ActivityLogItem {
  id: string
  report_id: string
  report_title: string
  action: ActivityAction
  performed_by: { name: string | null; email: string }
  note: string | null
  created_at: string
}

export interface User {
  id: string
  email: string
  name: string | null
  avatar_url: string | null
  role: UserRole
  is_banned: boolean
  created_at: string
}

export interface AdminStats {
  overview: {
    total: number
    pending: number
    approved: number
    rejected: number
    resolved: number
    today: number
  }
  trends: { date: string; count: number; approved: number; pending: number }[]
  by_category: { name: string; count: number; percentage: number }[]
  by_taluka: { name: string; count: number; percentage: number }[]
  by_status_history: {
    avg_review_time_hours: number
    approval_rate: number
  }
}

export interface SiteSettings {
  site_name: string
  site_tagline: string | null
  contact_email: string | null
  moderation_guidelines: string | null
  primary_color: string
  maintenance_mode: boolean
}

export interface PublicStats {
  total_reports: number
  approved_reports: number
  pending_reports: number
  resolved_reports: number
  rejected_reports: number
  category_breakdown: { category: string; count: number; color: string }[]
  taluka_breakdown: { taluka: string; count: number }[]
}
