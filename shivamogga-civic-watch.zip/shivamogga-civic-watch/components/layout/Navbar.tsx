"use client"

import Link from "next/link"
import { useState } from "react"
import { useSession, signIn, signOut } from "next-auth/react"
import { Menu, X, Shield, MapPin, LogIn, LogOut, User } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Navbar() {
  const { data: session, status } = useSession()
  const [mobileOpen, setMobileOpen] = useState(false)
  const isAdmin = session?.user?.role === "admin" || session?.user?.role === "super_admin"

  const links = [
    { href: "/", label: "Home" },
    { href: "/reports", label: "Reports" },
    { href: "/submit", label: "Submit Report" },
    { href: "/about", label: "About" },
  ]

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-bold text-xl text-primary">
          <MapPin className="h-6 w-6" />
          <span className="hidden sm:inline">Shivamogga Civic Watch</span>
          <span className="sm:hidden">SCW</span>
        </Link>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-6">
          {links.map(l => (
            <Link key={l.href} href={l.href} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              {l.label}
            </Link>
          ))}
          {isAdmin && (
            <Link href="/admin">
              <Button variant="ghost" size="sm">
                <Shield className="h-4 w-4 mr-1" />
                Admin
              </Button>
            </Link>
          )}
          {status === "authenticated" ? (
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground hidden lg:inline">{session.user?.name || session.user?.email}</span>
              <Button variant="ghost" size="sm" onClick={() => signOut()}>
                <LogOut className="h-4 w-4 mr-1" />
                Sign Out
              </Button>
            </div>
          ) : (
            <Button variant="ghost" size="sm" onClick={() => signIn("google")}>
              <LogIn className="h-4 w-4 mr-1" />
              Sign In
            </Button>
          )}
        </div>

        {/* Mobile toggle */}
        <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden border-t px-4 py-3 space-y-2">
          {links.map(l => (
            <Link key={l.href} href={l.href} className="block py-2 text-sm font-medium" onClick={() => setMobileOpen(false)}>
              {l.label}
            </Link>
          ))}
          {isAdmin && (
            <Link href="/admin" className="block py-2 text-sm font-medium text-primary" onClick={() => setMobileOpen(false)}>
              Admin Panel
            </Link>
          )}
          {status === "authenticated" ? (
            <button onClick={() => { signOut(); setMobileOpen(false); }} className="block py-2 text-sm font-medium text-red-600 w-full text-left">
              Sign Out
            </button>
          ) : (
            <button onClick={() => { signIn("google"); setMobileOpen(false); }} className="block py-2 text-sm font-medium text-primary w-full text-left">
              Sign In with Google
            </button>
          )}
        </div>
      )}
    </nav>
  )
}
