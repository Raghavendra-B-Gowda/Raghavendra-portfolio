import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  const categories = [
    { name_en: 'Roads & Potholes', name_kn: 'ರಸ್ತೆಗಳು ಮತ್ತು ಗಾಳುಗಲ್ಲುಗಳು', slug: 'roads-potholes', icon: 'road', color: '#ef4444', sort_order: 1 },
    { name_en: 'Water Supply', name_kn: 'ನೀರು ಪೂರೈಕೆ', slug: 'water-supply', icon: 'droplets', color: '#3b82f6', sort_order: 2 },
    { name_en: 'Waste Management', name_kn: 'ಕಸ ವಿಲೇವಾರಿ', slug: 'waste-management', icon: 'trash-2', color: '#22c55e', sort_order: 3 },
    { name_en: 'Public Funds', name_kn: 'ಸಾರ್ವಜನಿಕ ನಿಧಿ', slug: 'public-funds', icon: 'banknote', color: '#f59e0b', sort_order: 4 },
    { name_en: 'Environmental Issues', name_kn: 'ಪರಿಸರ ಸಮಸ್ಯೆಗಳು', slug: 'environmental', icon: 'tree-pine', color: '#10b981', sort_order: 5 },
    { name_en: 'Corruption', name_kn: 'ಭ್ರಷ್ಟಾಚಾರ', slug: 'corruption', icon: 'alert-triangle', color: '#dc2626', sort_order: 6 },
    { name_en: 'Public Infrastructure', name_kn: 'ಸಾರ್ವಜನಿಕ ಮೂಲಸೌಕರ್ಯ', slug: 'infrastructure', icon: 'building-2', color: '#6366f1', sort_order: 7 },
    { name_en: 'Education', name_kn: 'ಶಿಕ್ಷಣ', slug: 'education', icon: 'graduation-cap', color: '#8b5cf6', sort_order: 8 },
    { name_en: 'Healthcare', name_kn: 'ಆರೋಗ್ಯ', slug: 'healthcare', icon: 'heart-pulse', color: '#ec4899', sort_order: 9 },
    { name_en: 'Other', name_kn: 'ಇತರೆ', slug: 'other', icon: 'more-horizontal', color: '#6b7280', sort_order: 10 },
  ]

  for (const cat of categories) {
    await prisma.category.upsert({
      where: { slug: cat.slug },
      update: cat,
      create: cat,
    })
  }

  const talukas = [
    { name_en: 'Shivamogga', name_kn: 'ಶಿವಮೊಗ್ಗ', slug: 'shivamogga', latitude: 13.929930, longitude: 75.568101, sort_order: 1 },
    { name_en: 'Sagara', name_kn: 'ಸಾಗರ', slug: 'sagara', latitude: 14.165150, longitude: 75.029793, sort_order: 2 },
    { name_en: 'Thirthahalli', name_kn: 'ತೀರ್ಥಹಳ್ಳಿ', slug: 'thirthahalli', latitude: 13.688430, longitude: 75.245781, sort_order: 3 },
    { name_en: 'Hosanagara', name_kn: 'ಹೊಸನಗರ', slug: 'hosanagara', latitude: 14.280150, longitude: 75.061893, sort_order: 4 },
    { name_en: 'Shikaripura', name_kn: 'ಶಿಕಾರಿಪುರ', slug: 'shikaripura', latitude: 14.269430, longitude: 75.345781, sort_order: 5 },
    { name_en: 'Soraba', name_kn: 'ಸೊರಬ', slug: 'soraba', latitude: 14.380150, longitude: 75.161893, sort_order: 6 },
    { name_en: 'Bhadravati', name_kn: 'ಭದ್ರಾವತಿ', slug: 'bhadravati', latitude: 13.848430, longitude: 75.545781, sort_order: 7 },
  ]

  for (const taluka of talukas) {
    await prisma.taluka.upsert({
      where: { slug: taluka.slug },
      update: taluka,
      create: taluka,
    })
  }

  await prisma.adminSetting.upsert({
    where: { id: 1 },
    update: {},
    create: {
      site_name: 'Shivamogga District Civic Watch',
      site_tagline: 'Your Voice, Our District — Report Civic Issues Anonymously',
      contact_email: 'admin@shivamoggacivicwatch.org',
      moderation_guidelines: 'All reports are reviewed within 24 hours. Please ensure your report is factual, respectful, and includes evidence when possible.',
    },
  })

  console.log('✅ Seed completed')
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(async () => { await prisma.$disconnect() })
